/*
 *
 * Yasol: cliques.h -- Copyright (c) 2012-2017 Ulf Lorenz
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef MCTSCLASS_H
#define MCTSCLASS_H

#include "../graphClass/multiset_plus.h"
#include "../graphClass/graphClass.h"
#include <string>
#include <math.h>
#include <algorithm>

//class GraphManager {
  //void GraphManagerInitGraph(int n, bool lout) ;
  //int getNodeCnt();
  //bool AddEdge(int l1, int l2);
  //bool DeleteEdge(int l1, int l2);
  //bool getEdgeByIndex(int e, int &i, int &j);
  //int getAdjacent(int idx);
  //int FirstAdjacentInGraph(int i);
  //int NextAdjacentInGraph(int j);
  //void printGraph();
  //bool checkConsistency();
  //void initTestGraph(int n, bool lout);
//};

class Node {
 public:
  const double EQ_EPS = 1e-10;
  int ID;
  std::vector< std::pair< int,double > > DeltaSolution;
  double lowerBound;
  double upperBound;
  double pseudoScore;
  uint64_t pseudoScoreCnt;
  double Activity;
  bool isFullNode;
  int entryVar;
  int entryVal;
  int visits;
  bool isClosed;

  Node(int i, std::vector<double> &sol, std::vector<double> &sol_cmp, double lb, double ub, bool bndValid, double psScore, double Act, bool pseudoValid, bool activityValid, bool solutionValid, uint64_t & psCnt, int eVar, int eVal) {
    if (!isFullNode) isFullNode = solutionValid;
    ID = i;
    entryVar = eVar;
    entryVal = eVal;
    if (solutionValid) {
      DeltaSolution.clear();
      for (int z=0; z < sol.size();z++) {
	if (sol_cmp.size() != sol.size() || fabs(sol[z] - sol_cmp[z]) > EQ_EPS )
	  DeltaSolution.push_back(std::make_pair(z,sol[z]));
      }
    } else {
    }
    if (activityValid) {
      Activity = Act;
    }
    if (pseudoValid) {
      pseudoScore = psScore;
      pseudoScoreCnt = psCnt;
    }
    if (bndValid) {
      upperBound = ub;
      lowerBound = lb;
    }
    visits = 0;
    isClosed = false;
  }
  Node(int i) {
    ID = i;
    DeltaSolution.clear();
    Activity = 0.0;
    pseudoScore = 0.0;
    pseudoScoreCnt = 1.0;
    upperBound = (std::numeric_limits<double>::max)();
    lowerBound = -(std::numeric_limits<double>::max)();
    entryVar = -1;
    entryVal = -1;
    visits = 0;
    isClosed = false;
  }
  void updateLabel(int var, int val) {
    entryVar = var;
    entryVal = val;
    //cerr << "Node " << ID << " has got y" << var << "=" << val << endl;
  } 
  void updateVisits(int x) {
    visits += x;
    //cerr << "update node " << ID << " has " << visits << endl;
  } 
  void updateUpperBound(double newBnd) {
    upperBound = newBnd;
  }
  void updatePseudoCost(double *pCo, uint64_t *pCoCnt) {
    pseudoScore = *pCo;
    pseudoScoreCnt = *pCoCnt;
  }
  void updateActivity(double *ac) {
    Activity = *ac;
  }
};

class _MCTS {
 public:
  GraphManager GM;
  std::vector< Node > nodes;
  _MCTS() {
  }
  bool rootExists() {
    if (nodes.size() > 0) return true;
    else return false;
  }
  void AddRoot() {
    Node nd(0);
    assert(nodes.size()== 0);
    nodes.push_back(nd);
  }

  int findSucc(int id, int toVar, int toVal) {
    int j;
    j = GM.FirstAdjacentInGraph(id);
    if (j >= 0) {
      int w = GM.getAdjacent(j);
      //w first succ
      //cerr << "FOUND for ID=" << id << " x" << toVar << "=" << toVal << " :Succ=" << nodes[w].ID << " with y" << nodes[w].entryVar << "=" << nodes[w].entryVal << endl;
      if ( nodes[w].entryVar == toVar && nodes[w].entryVal == toVal) 
	return nodes[w].ID;
      int kk = GM.NextAdjacentInGraph(j);
      while (kk >= 0) {
	int w = GM.getAdjacent(kk);
	//cerr << "FOUND for ID=" << id << " x" << toVar << "=" << toVal << " :Succ=" << nodes[w].ID << " with y" << nodes[w].entryVar << "=" << nodes[w].entryVal << endl;
	// w next succ
	if ( nodes[w].entryVar == toVar && nodes[w].entryVal == toVal) 
	  return nodes[w].ID;
	kk = GM.NextAdjacentInGraph(kk);
      }
    }
    return -1;
  }

  void findBestSucc(int id, int &best_succ, int &best_dir, 
		    double* pseudo0score,
		    double* pseudo1score,
		    uint64_t* pseudo0scoreCnt,
		    uint64_t* pseudo1scoreCnt,
		    double* pActivity,
		    double* nActivity,
		    int8_t *assigns,
		    double upperBnd,
		    int n) {
    int j;
    int best_w=-1;
    double best_score = -(std::numeric_limits<double>::max)();
    best_succ = -1;

    if (1||id < 0) return;
    if (nodes[id].isClosed) {
      best_succ = -2;
      return;
    }

    best_dir = 0;
    std::vector<bool> pseudo0Exists;
    std::vector<bool> pseudo1Exists;
    std::vector<double> loss0;
    std::vector<double> loss1;
    std::vector<int> visits0;
    std::vector<int> visits1;
    for (int i = 0; i <n; i++) {
      pseudo0Exists.push_back(false);
      pseudo1Exists.push_back(false);
      loss0.push_back(0.0);
      loss1.push_back(0.0);
      visits0.push_back(0);
      visits1.push_back(0);
    }
    j = GM.FirstAdjacentInGraph(id);
    if (j >= 0) {
      int w = GM.getAdjacent(j);
      //w first succ
#define WEIGHTED_PSEUDO
      //#define MCTS_LIKE
#ifdef WEIGHTED_PSEUDO
	if ( nodes[w].entryVar >= 0 && assigns[nodes[w].entryVar] == 2 ) {
	  if (nodes[w].entryVal == 0) {
	    visits0[nodes[w].entryVar] = nodes[w].visits;
	    if (pseudo0scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo0Exists[nodes[w].entryVar] = true;
	      loss0[nodes[w].entryVar] = //nodes[w].visits+1;
		(1.0+0.1*(double)pseudo0scoreCnt[nodes[w].entryVar]/*nodes[w].visits*/)* (pseudo0score[nodes[w].entryVar] / (double)pseudo0scoreCnt[nodes[w].entryVar]); 
	    }
	  } else if (nodes[w].entryVal == 1) {
	    visits1[nodes[w].entryVar] = nodes[w].visits;
	    if (pseudo1scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo1Exists[nodes[w].entryVar] = true;
	      loss1[nodes[w].entryVar] = //nodes[w].visits+1;
		(1.0+0.1*(double)pseudo1scoreCnt[nodes[w].entryVar]/*nodes[w].visits*/)* (pseudo1score[nodes[w].entryVar] / (double)pseudo1scoreCnt[nodes[w].entryVar]); 
	    }
	  } else assert(0);
	}
#endif
#ifdef MCTS_LIKE
	if ( nodes[w].entryVar >= 0 && assigns[nodes[w].entryVar] == 2 ) {
	  if (nodes[w].entryVal == 0) {
	    visits0[nodes[w].entryVar] = nodes[w].visits;
	    if (1||pseudo0scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo0Exists[nodes[w].entryVar] = true;
	      loss0[nodes[w].entryVar] = 
		(10.0 / (10.0+(double)nodes[w].visits) ) * (pseudo0score[nodes[w].entryVar] / (double)pseudo0scoreCnt[nodes[w].entryVar]); 
	    }
	  } else if (nodes[w].entryVal == 1) {
	    visits1[nodes[w].entryVar] = nodes[w].visits;
	    if (1||pseudo1scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo1Exists[nodes[w].entryVar] = true;
	      loss1[nodes[w].entryVar] = 
		(10.0 / (10.0+(double)nodes[w].visits) )* (pseudo1score[nodes[w].entryVar] / (double)pseudo1scoreCnt[nodes[w].entryVar]); 
	    }
	  } else assert(0);
	}
#endif
      int kk = GM.NextAdjacentInGraph(j);
      while (kk >= 0) {
	int w = GM.getAdjacent(kk);
	// w next succ
#ifdef WEIGHTED_PSEUDO
	if ( nodes[w].entryVar >= 0 && assigns[nodes[w].entryVar] == 2 ) {
	  if (nodes[w].entryVal == 0) {
	    visits0[nodes[w].entryVar] = nodes[w].visits;
	    if (pseudo0scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo0Exists[nodes[w].entryVar] = true;
	      loss0[nodes[w].entryVar] = //nodes[w].visits+1;
		(1.0+0.1*(double)pseudo0scoreCnt[nodes[w].entryVar]/*nodes[w].visits*/)* (pseudo0score[nodes[w].entryVar] / (double)pseudo0scoreCnt[nodes[w].entryVar]); 
	    }
	  } else if (nodes[w].entryVal == 1) {
	    visits1[nodes[w].entryVar] = nodes[w].visits;
	    if (pseudo1scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo1Exists[nodes[w].entryVar] = true;
	      loss1[nodes[w].entryVar] = //nodes[w].visits+1;
		(1.0+0.1*(double)pseudo1scoreCnt[nodes[w].entryVar]/*nodes[w].visits*/)* (pseudo1score[nodes[w].entryVar] / (double)pseudo1scoreCnt[nodes[w].entryVar]); 
	    }
	  } else assert(0);
	}
#endif
#ifdef MCTS_LIKE
	if ( nodes[w].entryVar >= 0 && assigns[nodes[w].entryVar] == 2 ) {
	  if (nodes[w].entryVal == 0) {
	    visits0[nodes[w].entryVar] = nodes[w].visits;
	    if (1||pseudo0scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo0Exists[nodes[w].entryVar] = true;
	      loss0[nodes[w].entryVar] = 
		(10.0 / (10.0+(double)nodes[w].visits) ) * (pseudo0score[nodes[w].entryVar] / (double)pseudo0scoreCnt[nodes[w].entryVar]); 
	    }
	  } else if (nodes[w].entryVal == 1) {
	    visits1[nodes[w].entryVar] = nodes[w].visits;
	    if (1||pseudo1scoreCnt[nodes[w].entryVar] >= 1) {
	      pseudo1Exists[nodes[w].entryVar] = true;
	      loss1[nodes[w].entryVar] = 
		(10.0 / (10.0+(double)nodes[w].visits) )* (pseudo1score[nodes[w].entryVar] / (double)pseudo1scoreCnt[nodes[w].entryVar]); 
	    }
	  } else assert(0);
	}
#endif
	kk = GM.NextAdjacentInGraph(kk);
      }
    }

    //best_succ = -1;
    for (int i=0;i<n;i++) {
      if ((pseudo0Exists[i] && pseudo1Exists[i])) {
	double loss = loss0[i] * loss1[i];
	if (loss > best_score) {
	  best_score = loss;
	  best_succ = i;
	  if (loss0 > loss1) {//pseudo0score[i] / (double)pseudo0scoreCnt[i] < pseudo1score[i] / (double)pseudo1scoreCnt[i]) {
	    best_dir = 0;
	  } else {
	    best_dir = 1;
	  }
	}
      }
    }
    return;
    //if (best_w < 0) return;
    //best_succ = nodes[best_w].entryVar;
    //best_dir = nodes[best_w].entryVal;
  }

  void updateVisits(int id, int x) {
    nodes[id].updateVisits(x);
  } 
  void updateBounds(int nodeID, std::vector< std::pair< std::pair<double,double>, int > > &bndList, int n) {
    if (nodeID < 0) return;
    std::vector<int> bndListIdcs;
    for (int i=0; i < n;i++) {
      bndListIdcs.push_back(-1);
    }
    for (int i = 0; i < bndList.size();i++) {
      bndListIdcs[bndList[i].second] = i;
    }

    {
      int j;
      int id = nodeID;
      j = GM.FirstAdjacentInGraph(id);
      if (j >= 0) {
	int w = GM.getAdjacent(j);
	//w first succ
	int node = nodes[w].ID;
	int var = nodes[w].entryVar;
	int val = nodes[w].entryVal;
	if (bndListIdcs[var] >= 0) {
	  int i = bndListIdcs[var];
	  double nodeuBnd = (bndList[i].first.first > bndList[i].first.second ? bndList[i].first.first : bndList[i].first.second);
	  if (nodeuBnd < nodes[nodeID].upperBound) nodes[nodeID].upperBound = nodeuBnd;
	  if (nodeuBnd < nodes[node].upperBound) nodes[node].upperBound = nodeuBnd;
	}
	int kk = GM.NextAdjacentInGraph(j);
	while (kk >= 0) {
	  int w = GM.getAdjacent(kk);
	  // w next succ
	  int node = nodes[w].ID;
	  int var = nodes[w].entryVar;
	  int val = nodes[w].entryVal;
	  if (bndListIdcs[var] >= 0) {
	    int i = bndListIdcs[var];
	    double nodeuBnd = (bndList[i].first.first > bndList[i].first.second ? bndList[i].first.first : bndList[i].first.second);
	    if (nodeuBnd < nodes[nodeID].upperBound) nodes[nodeID].upperBound = nodeuBnd;
	    if (nodeuBnd < nodes[node].upperBound) nodes[node].upperBound = nodeuBnd;
	  }
	  kk = GM.NextAdjacentInGraph(kk);
	}
      }
    }
  }

  bool isClosed(int nodeID, double &l, double &u) {
    if (nodes[nodeID].isClosed == true) {
      l = nodes[nodeID].lowerBound;
      u = nodes[nodeID].upperBound;
      return true;
    } else return false;
    return false;
  }
  void setClosed(int nodeID, double l, double u) {
    nodes[nodeID].isClosed = true;
    nodes[nodeID].lowerBound = l;
    nodes[nodeID].upperBound = u;
  }

  void partialExpandOrUpdateNode(int id, std::vector<int> &vars, std::vector<int> &vals, int n,
			 double* pseudo0score,
			 double* pseudo1score,
			 uint64_t* pseudo0scoreCnt,
			 uint64_t* pseudo1scoreCnt,
			 double* pActivity,
			 double* nActivity) {
    std::vector<int> newLabels;
    for (int i=0; i < n;i++)
      newLabels.push_back(-1);
    assert(vars.size() == vals.size());
    for (int i = 0; i < vars.size();i++) {
      assert(vals[i] == 0 || vals[i] == 1);
      newLabels[vars[i]] = vals[i];
    }

    {
      /*
	for all succesors of id {
	if (label exists in successors)
	newLabels[...] = -1;
	}
      */
      int j;
      j = GM.FirstAdjacentInGraph(id);
      if (j >= 0) {
	int w = GM.getAdjacent(j);
	//w first succ
	if ( newLabels[ nodes[w].entryVar ] == nodes[w].entryVal) {
	  if (nodes[w].entryVal == 0) {
	    nodes[w].updatePseudoCost(&pseudo0score[nodes[w].entryVar], &pseudo0scoreCnt[nodes[w].entryVar]);
	    nodes[w].updateActivity(&nActivity[nodes[w].entryVar]);
	  } else {
	    nodes[w].updatePseudoCost(&pseudo1score[nodes[w].entryVar], &pseudo1scoreCnt[nodes[w].entryVar]);
	    nodes[w].updateActivity(&pActivity[nodes[w].entryVar]);
	  } 
	  newLabels[ nodes[w].entryVar ] = -1;
	}
	int kk = GM.NextAdjacentInGraph(j);
	while (kk >= 0) {
	  int w = GM.getAdjacent(kk);
	  // w next succ
	  if ( newLabels[ nodes[w].entryVar ] == nodes[w].entryVal) {
	    if (nodes[w].entryVal == 0) {
	      nodes[w].updatePseudoCost(&pseudo0score[nodes[w].entryVar], &pseudo0scoreCnt[nodes[w].entryVar]);
	      nodes[w].updateActivity(&nActivity[nodes[w].entryVar]);
	    } else {
	      nodes[w].updatePseudoCost(&pseudo1score[nodes[w].entryVar], &pseudo1scoreCnt[nodes[w].entryVar]);
	      nodes[w].updateActivity(&pActivity[nodes[w].entryVar]);
	    } 
	    newLabels[ nodes[w].entryVar ] = -1;
	  }
	  kk = GM.NextAdjacentInGraph(kk);
	}
      }
    }

    for (int i = 0; i < vars.size();i++) {
      if (newLabels[vars[i]] != -1) {
	int newID = nodes.size();
	Node nd(newID);
	nodes.push_back(nd);
	nodes[newID].updateLabel(vars[i], vals[i]);
	if (vals[i] == 0) {
	  nodes[newID].updatePseudoCost(&pseudo0score[vars[i]], &pseudo0scoreCnt[vars[i]]);
	  nodes[newID].updateActivity(&nActivity[vars[i]]);
	} else {
	  nodes[newID].updatePseudoCost(&pseudo1score[vars[i]], &pseudo1scoreCnt[vars[i]]);
	  nodes[newID].updateActivity(&pActivity[vars[i]]);
	} 
	GM.AddEdge(id,newID);
	//(id,vars[i],vals[i]) -> (newID) with searching, first of all
      }
    }

  }
};

#endif
